NOTE
====

These examples don't compile out of the box but are illustrative of
the template. YMMY.
